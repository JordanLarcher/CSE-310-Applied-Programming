using System;
using System.Threading.Tasks;

namespace TaskScheduler.Domain.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IUserRepository UserRepository { get; }
        ITaskRepository TaskRepository { get; }
        IReminderRepository  ReminderRepository { get; }
        ICategoryRepository CategoryRepository { get; }
        INotificationSettingsRepository NotificationSettingsRepository { get; }
        
        Task<int> SaveChangesAsync();
        Task BeginTransactionAsync();
        Task CommitAsync();
        Task RollBackAsync();
    }
}