using TaskScheduler.Domain.Enums;
using TaskStatus = System.Threading.Tasks.TaskStatus;

namespace TaskScheduler.Domain.Interfaces
{
    public interface ITaskRepository : IRepository<Task>
    {
        Task<IEnumerable<Task>> GetTaskByUserIdAsync(int userId);
        Task<IEnumerable<Task>> GetTaskByDateRangeAsync(int userId, DateTime startDate, DateTime endDate);
        Task<IEnumerable<Task>> GetOverdueTaskAsync(int userId);
        Task<IEnumerable<Task>> GetTasksByStatusAsync(int userId, TaskStatus status);
        Task<IEnumerable<Task>> GetTasksToCheckForOverdueAsync();
        Task<Dictionary<TaskPriority, int>> GetTaskStatisticsAsync(int userId);
        Task<IEnumerable<Task>> SearchTasksAsync(int userId, string searchTerm);
        Task<IEnumerable<Task>> GetTasksByCategoryAsync(int userId, int categoryId);
    }
}