namespace TaskScheduler.Domain.Interfaces;

public interface IReminderRepository
{
    
}