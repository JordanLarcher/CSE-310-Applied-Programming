using System.Security.Principal;
using Microsoft.AspNetCore.Identity;

namespace TaskScheduler.Shared
{
    public class ApplicationUser : IdentityUser
    {
        
    }
}