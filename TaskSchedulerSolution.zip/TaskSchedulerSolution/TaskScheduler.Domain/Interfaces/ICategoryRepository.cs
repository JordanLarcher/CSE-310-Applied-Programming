namespace TaskScheduler.Domain.Interfaces;

public class ICategoryRepository
{
    
}