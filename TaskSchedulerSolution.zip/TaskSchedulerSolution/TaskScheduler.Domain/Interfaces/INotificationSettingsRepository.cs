namespace TaskScheduler.Domain.Interfaces;

public class INotificationSettingsRepository
{
    
}