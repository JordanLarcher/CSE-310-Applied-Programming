namespace TaskScheduler.Domain.ValueObjects;

public class Email
{
    
}